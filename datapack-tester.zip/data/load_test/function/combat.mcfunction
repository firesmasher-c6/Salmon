# Spawn hostile cohorts around each simulated player
execute as @e[tag=lt_bot] at @s run summon minecraft:zombie ~2 ~ ~ {Tags:["lt_hostile"]}
execute as @e[tag=lt_bot] at @s run summon minecraft:skeleton ~-2 ~ ~ {Tags:["lt_hostile"]}
execute as @e[tag=lt_bot] at @s run summon minecraft:creeper ~ ~ ~3 {Tags:["lt_hostile"]}

# Simulate bots attacking nearby hostiles
execute as @e[tag=lt_bot] at @s run damage @e[tag=lt_hostile,distance=..8,limit=1,sort=nearest] 3 minecraft:player_attack

# Simulate hostiles damaging the bot representation (also pulses hurt attributes/particles)
execute as @e[tag=lt_hostile] at @s run damage @e[tag=lt_bot,limit=1,sort=nearest,distance=..8] 1 minecraft:mob_attack

# Add particles and sounds to approximate player PvP feedback
execute as @e[tag=lt_bot] at @s run particle minecraft:crit ~ ~1 ~ 0.3 0.5 0.3 0.1 5 normal
execute as @e[tag=lt_hostile] at @s run particle minecraft:explosion ~ ~1 ~ 0.2 0.2 0.2 0.05 1 normal