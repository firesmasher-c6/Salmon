# Simulate exploration movement for all 10 fake players
execute as @e[tag=lt_bot] at @s run tp @s ^0.25 ^ ^0.15 ~4 ~

# Occasionally force chunk borders to be crossed by jumping one bot per tick cohort
execute if score #global lt_timer matches 25 as @e[tag=lt_id4] at @s run tp @s ~20 ~ ~20
execute if score #global lt_timer matches 50 as @e[tag=lt_id6] at @s run tp @s ~-30 ~ ~10
execute if score #global lt_timer matches 75 as @e[tag=lt_id8] at @s run tp @s ~15 ~ ~-25
execute if score #global lt_timer matches 100 as @e[tag=lt_id10] at @s run tp @s ~-20 ~ ~-20

# Keep bots within the loaded simulation zone
execute as @e[tag=lt_bot] if entity @s[x=200,dx=1000] run tp @s 0 64 0
execute as @e[tag=lt_bot] if entity @s[x=-1000,dx=200] run tp @s 0 64 0
execute as @e[tag=lt_bot] if entity @s[z=200,dz=1000] run tp @s 0 64 0
execute as @e[tag=lt_bot] if entity @s[z=-1000,dz=200] run tp @s 0 64 0