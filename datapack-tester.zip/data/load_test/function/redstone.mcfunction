# Clear prior pulse region, then place a new one to generate redstone updates
fill 30 64 30 38 64 38 air
fill 30 64 30 38 64 38 minecraft:redstone_block

# Dense redstone-wire field with observers to exercise update paths
fill 50 64 50 58 64 58 minecraft:redstone_wire
fill 50 65 50 58 65 58 minecraft:observer[facing=up]

# Activate and deactivate several lamps/comparators in a second column
setblock 70 64 70 minecraft:redstone_lamp[lit=false]
fill 71 64 70 71 64 78 minecraft:repeater[facing=east]
setblock 70 64 70 minecraft:redstone_block

# Remove one field each cycle to keep block counts bounded
fill 40 64 40 43 64 43 air
fill 40 64 40 43 64 43 minecraft:piston[facing=up]
setblock 40 65 40 minecraft:redstone_torch