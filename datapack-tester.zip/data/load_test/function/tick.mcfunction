# Per-tick throttled simulation counters
scoreboard players add #global lt_timer 1
execute if score #global lt_timer matches 200.. run scoreboard players set #global lt_timer 0

# Exploration and idle AI-style movement every tick
function load_test:explore

# Redstone pulses on a fixed cadence (every 5 ticks)
scoreboard players add #redstone lt_timer 1
execute if score #redstone lt_timer matches 5.. run function load_test:redstone
execute if score #redstone lt_timer matches 5.. run scoreboard players set #redstone lt_timer 0

# Combat wave on a slower cadence (every 20 ticks)
scoreboard players add #combat lt_timer 1
execute if score #combat lt_timer matches 20.. run function load_test:combat
execute if score #combat lt_timer matches 20.. run scoreboard players set #combat lt_timer 0

# Hostile cleanup keeps entity counts from running away (every 100 ticks)
scoreboard players add #cleanup lt_timer 1
execute if score #cleanup lt_timer matches 100.. run kill @e[tag=lt_hostile]
execute if score #cleanup lt_timer matches 100.. run scoreboard players set #cleanup lt_timer 0