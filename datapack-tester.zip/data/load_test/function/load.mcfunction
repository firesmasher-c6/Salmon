# Salmon load-test datapack bootstrap
scoreboard objectives add lt_timer dummy
scoreboard objectives add lt_bot_id dummy

# Force-load a chunk area so redstone/exploration targets stay loaded

# Clean previous test entities
kill @e[tag=lt_bot]
kill @e[tag=lt_hostile]

# Spawn 10 fake "players" (armor stands) in a circle
summon minecraft:armor_stand 10 64 0 {CustomName:'{"text":"LoadBot-1","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id1"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand 7 64 7 {CustomName:'{"text":"LoadBot-2","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id2"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand 0 64 10 {CustomName:'{"text":"LoadBot-3","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id3"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand -7 64 7 {CustomName:'{"text":"LoadBot-4","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id4"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand -10 64 0 {CustomName:'{"text":"LoadBot-5","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id5"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand -7 64 -7 {CustomName:'{"text":"LoadBot-6","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id6"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand 0 64 -10 {CustomName:'{"text":"LoadBot-7","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id7"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand 7 64 -7 {CustomName:'{"text":"LoadBot-8","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id8"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand 14 64 0 {CustomName:'{"text":"LoadBot-9","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id9"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}
summon minecraft:armor_stand -14 64 0 {CustomName:'{"text":"LoadBot-10","color":"aqua"}',CustomNameVisible:1b,Tags:["lt_bot","lt_id10"],NoGravity:1b,Marker:0b,Invisible:0b,PersistenceRequired:1b}

tellraw @a {"text":"[LoadTest] 10 simulated players spawned. Exploration, combat, and redstone load enabled.","color":"green"}
